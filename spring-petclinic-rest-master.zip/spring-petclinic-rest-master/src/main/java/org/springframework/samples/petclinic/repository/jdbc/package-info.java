
package org.springframework.samples.petclinic.repository.jdbc;

