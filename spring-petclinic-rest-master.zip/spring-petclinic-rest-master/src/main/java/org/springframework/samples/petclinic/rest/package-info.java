

package org.springframework.samples.petclinic.rest;