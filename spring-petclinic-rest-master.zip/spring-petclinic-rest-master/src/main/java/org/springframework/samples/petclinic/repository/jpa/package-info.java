
package org.springframework.samples.petclinic.repository.jpa;

